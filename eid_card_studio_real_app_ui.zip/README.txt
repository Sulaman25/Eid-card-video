Eid Card Studio App UI

What changed:
- app-style interface with tabs
- sticky top bar
- bottom action bar
- mobile-first controls
- same working premium card engine underneath
- one-click export all PNGs

Use:
1. Replace your repo root index.html with this one
2. Refresh your site
3. Use the tabs like an app
