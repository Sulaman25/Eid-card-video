Eid Card Studio Pro Merge

This fixes the drift and merges properly:
- keeps the premium visual card
- keeps dynamic languages
- keeps one custom personal note
- adds recipient list + current recipient selector
- lets you switch recipients without losing your design
- exports the current recipient card as PNG or silent video

How to use:
1. Replace your repo root index.html with this one.
2. Load your recipient names.
3. Switch recipients as needed.
4. Export PNG/video for the current recipient.
